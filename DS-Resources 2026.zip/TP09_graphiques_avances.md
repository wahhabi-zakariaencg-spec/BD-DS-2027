# TP 09 : Graphiques avancés (barres et camembert)

**Notebook source :** `09_graphiques_avances.ipynb`
**Jeu de données :** `data.csv` après nettoyage
**Objectif :** choisir le bon type de graphique selon la nature des données (courbe, barres, secteurs).

---

## Contexte

Le type de graphique dépend de la question et du type de variable :

| Question | Variable | Graphique adapté |
|---|---|---|
| Comment évolue une quantité ? | temps | courbe |
| Comment se comparent des catégories ? | catégorielle | barres |
| Comment se répartit un tout ? | catégorielle, peu de modalités | secteurs (camembert) |
| Comment se distribue une valeur ? | numérique | histogramme, boîte à moustaches |

Ce TP illustre les trois premiers cas, et montre au passage une erreur de choix.

---

## Instruction par instruction

### 1. Préparation et nettoyage

```python
import pandas as pd
df = pd.read_csv("data.csv")
df.dropna(subset=["tax"], inplace=True)
df.price_paid = df.price_paid.apply(lambda x: x.replace("$", ""))
df.price_paid = df.price_paid.astype(float)
df["price_total"] = df["price_paid"] * (1 - df["tax"] / 100)
df.drop(["first_name", "last_name", "email", "ip_address", "id"], axis=1, inplace=True)
```

- Identique aux TP 07 et 08.

### 2. Ventes par pays en courbe

```python
df.groupby("country")["price_total"].sum().plot()
```

- Calcule le total des ventes par pays (Canada 536,76 ; France 1 289,37 ; Morocco 211,05 ; United States 1 178,88), puis trace une **courbe**.
- **Ce graphique est inadapté.** Une courbe relie les points, ce qui suggère une continuité ou une évolution entre le Canada, la France, le Maroc et les États-Unis. Or les pays sont des catégories sans ordre : le trait entre deux pays ne signifie rien. C'est un bon contre-exemple pédagogique, qui justifie l'instruction suivante.

### 3. Ventes par pays en barres

```python
df.groupby("country")["price_paid"].sum().plot.bar(rot=45, legend=True)
```

- `.plot.bar()` trace un **diagramme en barres verticales** : une barre par pays, dont la hauteur est la somme des prix. C'est le bon choix pour comparer des catégories.
- `rot=45` incline les étiquettes de l'axe horizontal de 45 degrés pour éviter qu'elles se chevauchent.
- `legend=True` affiche une légende avec le nom de la série (`price_paid`).
- Remarque : on additionne ici `price_paid` et non `price_total` comme à l'instruction précédente. Le changement n'est pas expliqué ; pour comparer les deux graphiques, il faudrait la même colonne.
- Variantes : `.plot.barh()` pour des barres horizontales (pratique pour les noms longs), et `.sort_values()` avant `.plot` pour classer les barres.

### 4. Répartition par genre en camembert

```python
df["gender"].value_counts(normalize=True).plot.pie(legend=True, figsize=(7, 7))
```

- `value_counts(normalize=True)` donne les proportions de chaque genre (Female 52,8 %, Male 47,2 %).
- `.plot.pie()` trace un **diagramme en secteurs** : chaque part est proportionnelle à la valeur. (Le `normalize=True` n'est pas indispensable : un camembert calcule lui-même les proportions.)
- `figsize=(7, 7)` donne une figure carrée pour que le cercle ne soit pas déformé.
- `legend=True` ajoute une légende.
- Les 42 lignes sans genre ne figurent pas dans le graphique, ce qu'il faudrait signaler au lecteur.
- Pour afficher les pourcentages sur les parts : `autopct="%1.1f%%"`.
- Limite : l'œil compare mal les angles. Au-delà de 3 ou 4 catégories, ou pour comparer des parts proches, un diagramme en barres est plus lisible.

---

## Les principaux types de `.plot`

| Syntaxe | Graphique |
|---|---|
| `.plot()` ou `.plot.line()` | courbe |
| `.plot.bar()` / `.plot.barh()` | barres verticales / horizontales |
| `.plot.pie()` | secteurs |
| `.plot.hist(bins=20)` | histogramme |
| `.plot.box()` | boîte à moustaches |
| `df.plot.scatter(x="a", y="b")` | nuage de points |

Pour aller plus loin que `.plot()` : **seaborn** (graphiques statistiques élégants) et **plotly** (graphiques interactifs).

## À retenir

- Le type de variable dicte le type de graphique.
- Pas de courbe entre des catégories sans ordre.
- Un bon graphique a un titre, des axes nommés et signale les données exclues.

## Pour s'exercer

1. Refaire le diagramme en barres avec `price_total`, trié par ordre décroissant, avec un titre.
2. Tracer l'histogramme de `price_paid` avec 15 classes.
3. Tracer un diagramme en barres groupées genre × pays : `df.groupby(["country", "gender"])["price_total"].mean().unstack().plot.bar()`.
