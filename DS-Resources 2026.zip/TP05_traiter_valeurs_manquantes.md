# TP 05 : Traiter les valeurs manquantes

**Notebook source :** `05_traiter_valeurs_manquantes.ipynb`
**Jeu de données :** `data.csv`
**Objectif :** détecter les valeurs manquantes (`NaN`), puis choisir entre les conserver, les remplacer ou supprimer les lignes concernées.

---

## Contexte

Les données réelles sont incomplètes : formulaire mal rempli, capteur en panne, information non collectée. Dans `data.csv`, il manque 346 valeurs de `tax`, 69 de `gender` et 44 de `country`. La plupart des calculs et presque tous les modèles de machine learning ne savent pas gérer un `NaN` : il faut donc décider quoi en faire. Cette décision a des conséquences sur les résultats et doit toujours être justifiée.

Le notebook liste six outils : `isnull()`, `notnull()`, `dropna()`, `fillna()`, `replace()`, `interpolate()`. Les quatre premiers sont démontrés.

---

## Instruction par instruction

### 1. Préparation

```python
import pandas as pd
df = pd.read_csv("data.csv")
```

### 2. Détecter les valeurs manquantes

```python
df.isnull()
```

- Renvoie un DataFrame de **même taille** que `df` (1 000 × 10) rempli de booléens : `True` là où la valeur manque.
- Seul, ce tableau est peu lisible. On le combine presque toujours avec `sum()` : `df.isnull().sum()` compte les manquants par colonne (`True` vaut 1, `False` vaut 0).
- `isna()` est un synonyme strict de `isnull()`.

```python
df.notnull()
```

- L'inverse exact : `True` là où une valeur est présente. Synonyme : `notna()`.

```python
df[df["tax"].notnull()]
```

- Utilise `notnull()` comme **masque de filtre** (voir TP 03) : on garde les 654 lignes où la taxe est renseignée.

### 3. Stratégie 1 : remplir avec une valeur voisine

```python
df["tax"].fillna(method='bfill')
```

- `fillna` remplace les `NaN`. Avec `method='bfill'` (*backward fill*), chaque valeur manquante reçoit la **valeur suivante** non nulle de la colonne.
- **Correction du notebook :** le texte annonce qu'on utilise « les valeurs précédentes ». C'est l'inverse : la valeur précédente correspond à `ffill` (*forward fill*), la suivante à `bfill`.
- **Compatibilité :** le paramètre `method` est déprécié depuis pandas 2.1 et **supprimé dans pandas 3** (`TypeError`). Écriture actuelle :
  ```python
  df["tax"].bfill()   # valeur suivante
  df["tax"].ffill()   # valeur précédente
  ```
- **Pertinence :** cette méthode a du sens pour des données **ordonnées** dans le temps (une température relevée toutes les heures). Ici, chaque ligne est un client indépendant : recopier la taxe du client voisin n'a pas de justification. C'est l'occasion d'en discuter.
- Le résultat n'est pas réaffecté : `df` reste inchangé.

### 4. Stratégie 2 : remplir avec une valeur par défaut

```python
df["tax"].fillna(0)
```

- Remplace tous les `NaN` de `tax` par `0`.
- Cela revient à **affirmer** que ces achats n'ont pas de taxe. C'est raisonnable seulement si l'absence de valeur signifie réellement « pas de taxe » ; sinon on introduit une erreur.
- Autres choix fréquents : la moyenne (`df["tax"].fillna(df["tax"].mean())`), la médiane, ou la valeur la plus fréquente (le mode) pour une colonne de texte.

### 5. Stratégie 3 : supprimer les lignes incomplètes

```python
df.dropna(subset=["tax"])
```

- Supprime les lignes où `tax` est manquante. Il en reste 654.
- `subset=["tax"]` limite le test à cette colonne. Sans ce paramètre, `dropna()` supprimerait toute ligne ayant **au moins un** `NaN` dans n'importe quelle colonne, ce qui retirerait encore plus de données.
- C'est cette stratégie que retiennent les TP 06 à 09 (avec `inplace=True`).
- Coût : on perd 34,6 % des lignes. Si les lignes supprimées diffèrent des autres (par exemple un pays sans taxe), les résultats deviennent **biaisés**.

---

## Les deux outils non démontrés

| Outil | Usage | Exemple |
|---|---|---|
| `replace()` | remplacer des valeurs précises, y compris des codes signifiant « manquant » | `df.replace("N/A", pd.NA)` |
| `interpolate()` | estimer une valeur manquante à partir des voisines (linéairement par défaut) | séries temporelles numériques |

---

## Choisir une stratégie

| Stratégie | Quand l'utiliser | Risque |
|---|---|---|
| Supprimer (`dropna`) | peu de manquants, répartis au hasard | perte d'information, biais |
| Valeur fixe (`fillna(0)`) | l'absence a un sens connu | fausse information |
| Moyenne / médiane | variable numérique, manquants aléatoires | réduit artificiellement la variance |
| `ffill` / `bfill` / `interpolate` | données ordonnées dans le temps | non pertinent sinon |
| Conserver | l'outil utilisé sait gérer `NaN` | certains calculs ignorent silencieusement les `NaN` |

## À retenir

- `isnull().sum()` est le réflexe pour mesurer l'ampleur du problème.
- Aucune méthode n'est neutre : chaque choix modifie les résultats.
- Rien n'est modifié sans réaffectation ou `inplace=True`.

## Pour s'exercer

1. Calculer le pourcentage de valeurs manquantes par colonne : `df.isnull().mean() * 100`.
2. Remplacer les `NaN` de `country` par `"Inconnu"`.
3. Comparer le nombre de lignes après `df.dropna()` et après `df.dropna(subset=["tax"])`.
