"""Prédire la durée d'un film Netflix (en minutes) par régression linéaire."""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# 1. Données : uniquement les films, durée convertie en entier
df = pd.read_csv("netflix_titles.csv")
films = df[df["type"] == "Movie"].copy()
films["duree"] = films["duration"].str.replace(" min", "", regex=False).astype(int)

# 2. Variables explicatives
GENRES = {
    "Dramas": "drame", "Comedies": "comedie", "Documentaries": "documentaire",
    "Action & Adventure": "action", "Children & Family Movies": "jeunesse_famille",
    "Romantic Movies": "romance", "Stand-Up Comedy": "standup",
    "Horror Movies": "horreur", "Music & Musicals": "musical",
    "International Movies": "international",
}
X = pd.DataFrame(index=films.index)
X["annee_depuis_2000"] = films["release_year"] - 2000
for genre_en, nom in GENRES.items():
    X[nom] = films["listed_in"].str.contains(genre_en, regex=False).astype(int)
pays = films["country"].fillna("")
X["inde"] = pays.str.contains("India").astype(int)
X["etats_unis"] = pays.str.contains("United States").astype(int)
y = films["duree"]

# 3. Séparation entraînement / test (80 % / 20 %)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 4. Référence naïve : prédire toujours la moyenne d'entraînement
base = np.full(len(y_test), y_train.mean())

# 5. Modèle
modele = LinearRegression().fit(X_train, y_train)
pred = modele.predict(X_test)

def scores(nom, p):
    print(f"{nom:<22} MAE={mean_absolute_error(y_test, p):6.2f}  "
          f"RMSE={mean_squared_error(y_test, p) ** 0.5:6.2f}  R2={r2_score(y_test, p):.3f}")

print(f"Films : {len(films)} | entraînement : {len(X_train)} | test : {len(X_test)}")
print(f"Moyenne d'entraînement : {y_train.mean():.2f} min")
scores("Référence (moyenne)", base)
scores("Régression linéaire", pred)
print(f"\nConstante (b0) : {modele.intercept_:.2f}")
for nom, coef in sorted(zip(X.columns, modele.coef_), key=lambda t: -abs(t[1])):
    print(f"  {nom:<20} {coef:+7.2f}")

# 6. Validation croisée (5 plis) pour vérifier la stabilité du R2
from sklearn.model_selection import cross_val_score
cv = cross_val_score(LinearRegression(), X, y, cv=5, scoring="r2")
print(f"\nR2 en validation croisée : {cv.mean():.3f} (écart-type {cv.std():.3f})")

# 7. Exemples de prédiction
exemples = pd.DataFrame([
    dict(annee_depuis_2000=19, drame=1, international=1, inde=1),
    dict(annee_depuis_2000=20, documentaire=1, etats_unis=1),
    dict(annee_depuis_2000=18, standup=1, etats_unis=1),
    dict(annee_depuis_2000=10, action=1, etats_unis=1),
]).reindex(columns=X.columns).fillna(0)
print("\nExemples :", np.round(modele.predict(exemples), 1))
