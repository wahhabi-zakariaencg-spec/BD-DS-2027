# TP 01 : Lecture d'un fichier CSV

**Notebook source :** `01_lecture_fichier.ipynb`
**Jeu de données :** `data.csv` (1 000 transactions fictives, mars 2021)
**Objectif :** charger un fichier de données dans Python et obtenir un premier tableau manipulable.

---

## Contexte

Avant toute analyse, il faut transformer un fichier stocké sur le disque en un objet que Python sait manipuler. La bibliothèque **pandas** fournit cet objet : le **DataFrame**, un tableau à deux dimensions avec des lignes (rangées), des colonnes nommées et un index. Ce TP est la porte d'entrée de toute la formation : chaque notebook suivant commence par les deux mêmes instructions.

---

## Instruction par instruction

### 1. Importer pandas

```python
import pandas as pd
```

- `import pandas` charge la bibliothèque en mémoire.
- `as pd` lui donne un alias court. C'est une convention universelle : toute la documentation et tous les tutoriels écrivent `pd.`, ce qui rend le code immédiatement lisible par d'autres.
- Cette instruction ne produit aucun affichage. Si pandas n'est pas installé, on obtient `ModuleNotFoundError`, qu'on corrige avec `pip install pandas`.

### 2. Lire le fichier et l'afficher

```python
df = pd.read_csv("data.csv")
print(df)
```

**`pd.read_csv("data.csv")`**
- Lit le fichier ligne par ligne, découpe chaque ligne aux virgules, utilise la première ligne comme noms de colonnes et devine le type de chaque colonne (entier, décimal, texte).
- Le chemin `"data.csv"` est **relatif** : le fichier doit se trouver dans le même dossier que le notebook. Sinon, on obtient `FileNotFoundError`.
- Pandas crée automatiquement un index numérique de 0 à 999.

**`df = ...`**
- Le résultat est stocké dans la variable `df` (abréviation de *DataFrame*, autre convention très répandue).

**`print(df)`**
- Affiche une version abrégée du tableau : les 5 premières et 5 dernières lignes, avec `...` au milieu, puis la taille : `[1000 rows x 10 columns]`.
- Dans Jupyter, écrire simplement `df` en dernière ligne d'une cellule donne un affichage plus lisible (tableau HTML).

**Ce que l'on observe déjà dans le résultat :**

| Colonne | Contenu | Remarque |
|---|---|---|
| `id` | identifiant de 1 à 1000 | entier |
| `date` | date d'achat, ex. `03/28/2021` | format américain MM/JJ/AAAA, lu comme **texte** |
| `first_name`, `last_name`, `email` | identité du client | texte |
| `gender` | `Male` / `Female` | contient des `NaN` |
| `ip_address` | adresse IP | texte |
| `country` | pays | contient des `NaN` |
| `price_paid` | prix, ex. `$5.36` | lu comme **texte** à cause du symbole `$` |
| `tax` | taxe en % | `20.0` ou `NaN` |

`NaN` (*Not a Number*) est la façon dont pandas représente une **valeur manquante**. On voit dès cette première lecture que les données ne sont pas « propres » : c'est ce qui justifie les TP 03 à 06.

---

## Les autres fonctions de lecture

Le notebook mentionne la famille `read_*`. Les plus courantes :

| Fonction | Format |
|---|---|
| `pd.read_csv()` | CSV, TSV (avec `sep="\t"`) |
| `pd.read_excel()` | Excel `.xlsx` / `.xls` |
| `pd.read_json()` | JSON |
| `pd.read_sql()` | résultat d'une requête SQL |
| `pd.read_parquet()` | Parquet (format compact utilisé en big data) |

Paramètres utiles de `read_csv` : `sep` (séparateur, ex. `";"` pour les CSV français), `encoding` (ex. `"latin-1"`), `nrows` (lire seulement les N premières lignes), `usecols` (lire certaines colonnes), `parse_dates` (convertir directement une colonne en date).

---

## À retenir

- `import pandas as pd` puis `df = pd.read_csv(...)` : le point de départ de tout projet.
- Pandas devine les types, mais pas toujours correctement (`price_paid` et `date` sont restés du texte).
- Une première lecture sert aussi à repérer les problèmes de qualité des données.

## Pour s'exercer

1. Relire le fichier en ne gardant que les colonnes `date`, `country` et `price_paid` (`usecols`).
2. Relire le fichier en convertissant directement la date (`parse_dates=["date"]`) et vérifier le type avec `df.dtypes`.
