# TP 08 : Premier graphique

**Notebook source :** `08_graphiques.ipynb`
**Jeu de données :** `data.csv` après nettoyage
**Objectif :** produire un graphique directement depuis pandas pour visualiser l'évolution des ventes jour par jour.

---

## Contexte

Un tableau de 30 chiffres se lit mal ; une courbe montre immédiatement les tendances, les pics et les creux. Pandas intègre une méthode `.plot()` qui s'appuie sur la bibliothèque **matplotlib** et permet de tracer un graphique en une ligne.

---

## Instruction par instruction

### 1. Préparation et nettoyage

```python
import pandas as pd
df = pd.read_csv("data.csv")
df.dropna(subset=["tax"], inplace=True)
df.price_paid = df.price_paid.apply(lambda x: x.replace("$", ""))
df.price_paid = df.price_paid.astype(float)
df["price_total"] = df["price_paid"] * (1 - df["tax"] / 100)
df.drop(["first_name", "last_name", "email", "ip_address", "id"], axis=1, inplace=True)
```

- Même chaîne de préparation que le TP 07 (voir TP 05, 06 et 04 pour le détail de chaque ligne).
- matplotlib doit être installé (`pip install matplotlib`), même si on ne l'importe pas explicitement.

### 2. Tracer les ventes par jour

```python
df.groupby("date")["price_total"].sum().plot(figsize=[20, 10])
```

Cette ligne enchaîne trois opérations, à lire de gauche à droite :

1. **`df.groupby("date")`** : regroupe les achats par jour.
2. **`["price_total"].sum()`** : calcule le total des ventes de chaque jour. On obtient une Series de 30 valeurs, indexée par la date.
3. **`.plot(figsize=[20, 10])`** : trace cette Series.
   - Pour une Series, le type par défaut est une **courbe** (`kind="line"`).
   - L'**index** (les dates) va sur l'axe horizontal, les **valeurs** (les totaux) sur l'axe vertical.
   - `figsize=[20, 10]` fixe la taille de la figure en pouces (largeur, hauteur).

Cet enchaînement de méthodes s'appelle le **chaînage** (*method chaining*) : chaque méthode s'applique au résultat de la précédente.

**Lecture du résultat :** les ventes quotidiennes varient entre environ 59 et 163, avec un pic le 16 mars. Aucune tendance de fond nette sur le mois.

---

## Point de vigilance : les dates sont du texte

La colonne `date` n'a jamais été convertie : ce sont des chaînes comme `"03/16/2021"`. Le `groupby` les trie donc par **ordre alphabétique**, pas chronologique. Ici le résultat est correct par chance, car toutes les dates sont du même mois et au format MM/JJ/AAAA. Avec des données sur plusieurs mois ou années, `"01/05/2022"` passerait avant `"12/30/2021"` et la courbe serait fausse.

La bonne pratique consiste à convertir la colonne :

```python
df["date"] = pd.to_datetime(df["date"], format="%m/%d/%Y")
df.groupby("date")["price_total"].sum().plot(figsize=(20, 10))
```

Avantages : tri chronologique garanti, axe horizontal mieux formaté, et accès à `df["date"].dt.day_name()` (jour de la semaine), `.dt.month`, etc.

---

## Améliorer le graphique

```python
ax = df.groupby("date")["price_total"].sum().plot(
    figsize=(12, 5),
    title="Ventes quotidiennes, mars 2021",
    marker="o",
    grid=True,
)
ax.set_xlabel("Date")
ax.set_ylabel("Ventes ($)")
```

- `title`, `marker`, `grid` : options de `.plot()`.
- `.plot()` renvoie un objet **Axes** de matplotlib, sur lequel on peut nommer les axes.
- Un graphique sans titre ni axes nommés est difficile à interpréter par quelqu'un d'autre.

## À retenir

- `serie.plot()` trace l'index en abscisse et les valeurs en ordonnée.
- `groupby(...)[...].sum().plot()` est un schéma très courant.
- Convertir les dates avec `pd.to_datetime` avant toute analyse temporelle.

## Pour s'exercer

1. Ajouter une moyenne mobile sur 7 jours (`.rolling(7).mean()`) et la tracer sur le même graphique.
2. Après conversion des dates, calculer et tracer les ventes moyennes par jour de la semaine.
