# Les bases de la data science avec pandas : fiches de TP

Ce dossier explique, instruction par instruction, les notebooks de la formation « Les bases de la data science avec pandas » (Docstring), puis récapitule le projet d'analyse Netflix et son prolongement en machine learning.

## Contenu

| Fichier | Thème | Notions principales |
|---|---|---|
| `TP01_lecture_fichier.md` | Lire un fichier | `import pandas as pd`, `read_csv`, famille `read_*` |
| `TP02_analyser_dataframe.md` | Inspecter un tableau | `head`, `tail`, `shape`, `columns`, `index`, `set_index` |
| `TP03_selectionner_des_donnees.md` | Sélectionner | Series / DataFrame, `loc`, `iloc`, filtres, `isin`, conversion de type |
| `TP04_supprimer_des_colonnes.md` | Supprimer | `drop`, `axis`, `inplace`, `del` |
| `TP05_traiter_valeurs_manquantes.md` | Valeurs manquantes | `isnull`, `notnull`, `fillna`, `bfill`, `dropna` |
| `TP06_ajouter_des_donnees.md` | Créer des colonnes | colonnes calculées, `map` avec un dictionnaire |
| `TP07_analyser_des_donnees.md` | Statistiques | `describe`, `value_counts`, `groupby` |
| `TP08_graphiques.md` | Premier graphique | `.plot()`, chaînage, dates |
| `TP09_graphiques_avances.md` | Choisir son graphique | barres, secteurs, courbe |
| `Projet_Netflix_analyse_et_machine_learning.md` | Projet de synthèse | analyse exploratoire, régression linéaire, fonction de prédiction |
| `netflix_ml.py` | Script du modèle | entraînement, évaluation, coefficients |

## Ordre de lecture conseillé

TP 01 à 09 dans l'ordre, puis le projet Netflix. Les TP 06 à 09 reprennent en tête la même chaîne de nettoyage (TP 04, 05 et 06).

## Structure de chaque fiche

1. Objectif et contexte
2. Explication de chaque instruction du notebook, avec les résultats obtenus
3. Points de vigilance (erreurs, compatibilité)
4. À retenir
5. Exercices

## Jeux de données

- `data.csv` : 1 000 transactions fictives de mars 2021 (TP 01 à 09).
- `netflix_titles.csv` : 7 787 titres du catalogue Netflix, extrait de janvier 2021 (projet).

## Compatibilité

Les notebooks ont été écrits pour Python 3.9 et une ancienne version de pandas. Trois instructions ne fonctionnent plus, ou plus correctement, avec pandas 2 et 3 ; les fiches donnent à chaque fois la version corrigée :

- `fillna(method='bfill')` (TP 05) : utiliser `.bfill()` ;
- `groupby(...).mean()` sur un tableau contenant du texte (TP 07) : sélectionner les colonnes numériques ;
- `groupby(...).sum()` (TP 07) : même correction, sinon les dates sont concaténées.

Les résultats chiffrés des fiches ont été vérifiés avec pandas 3.0 et scikit-learn 1.8.
