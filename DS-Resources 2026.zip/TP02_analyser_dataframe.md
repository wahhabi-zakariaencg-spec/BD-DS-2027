# TP 02 : Analyser la structure d'un DataFrame

**Notebook source :** `02_analyser_dataframe.ipynb`
**Jeu de données :** `data.csv`
**Objectif :** inspecter rapidement un tableau pour comprendre sa taille, ses colonnes et son index avant de l'analyser.

---

## Contexte

Un DataFrame de 1 000 lignes ne se lit pas en entier. Le réflexe du data scientist est d'en regarder des échantillons et des métadonnées (taille, noms de colonnes, index). C'est l'étape d'**exploration initiale**.

---

## Instruction par instruction

### 1. Préparation

```python
import pandas as pd
df = pd.read_csv("data.csv")
```

Identique au TP 01 : on importe pandas et on charge les données dans `df`.

### 2. Voir le début du tableau

```python
df.head()
```

- Retourne les **5 premières lignes** (valeur par défaut).
- C'est une **méthode** (avec parenthèses) : elle renvoie un nouveau DataFrame sans modifier `df`.
- Usage : vérifier que la lecture s'est bien passée (bons séparateurs, bons noms de colonnes).

### 3. Voir la fin du tableau

```python
df.tail()
```

- Retourne les **5 dernières lignes** (index 995 à 999).
- Utile pour vérifier qu'il n'y a pas de ligne parasite en fin de fichier (total, ligne vide, commentaire).

### 4. Choisir le nombre de lignes

```python
df.head(10)
```

- Le paramètre indique le nombre de lignes voulu : ici les 10 premières. Fonctionne aussi avec `tail(n)`.

### 5. Connaître la taille

```python
df.shape
```

- Retourne un **tuple** `(nombre de lignes, nombre de colonnes)`, ici `(1000, 10)`.
- C'est un **attribut**, pas une méthode : pas de parenthèses. Écrire `df.shape()` provoquerait une erreur (`'tuple' object is not callable`).
- `df.shape[0]` donne le nombre de lignes, `df.shape[1]` le nombre de colonnes.

### 6. Lister les colonnes

```python
df.columns.tolist()
```

- `df.columns` est un objet `Index` contenant les noms de colonnes.
- `.tolist()` le convertit en **liste Python** classique, plus simple à lire et à réutiliser :
  `['id', 'date', 'first_name', 'last_name', 'email', 'gender', 'ip_address', 'country', 'price_paid', 'tax']`
- Indispensable pour copier les noms exacts (une faute de frappe dans un nom de colonne donne une `KeyError`).

### 7. Voir l'index

```python
df.index.tolist()[:10]
```

- `df.index` contient les **étiquettes des lignes**. Ici pandas a créé un `RangeIndex` de 0 à 999.
- `.tolist()` le convertit en liste, `[:10]` garde les 10 premiers éléments (découpage Python classique) : `[0, 1, 2, ..., 9]`.
- L'index n'est pas une colonne comme les autres : il sert à **identifier** et **retrouver** les lignes (voir `loc` au TP 03).

### 8. Changer l'index

```python
df.set_index("email")
```

- Utilise la colonne `email` comme index : chaque ligne est désormais identifiée par l'adresse courriel du client. La colonne `email` disparaît des colonnes ordinaires et devient l'étiquette des lignes.
- Choisir un index pertinent (un identifiant unique) facilite les recherches : on pourra écrire `df.loc["hharridge1@gnu.org"]`.
- **Point important :** cette instruction **ne modifie pas `df`**. Elle renvoie une copie modifiée qui est seulement affichée. Pour conserver le changement, il faut soit réaffecter (`df = df.set_index("email")`), soit écrire `df.set_index("email", inplace=True)`. C'est un piège très fréquent chez les débutants, et le TP 03 utilise la première solution.

---

## Compléments utiles (non présents dans le notebook)

| Instruction | Ce qu'elle donne |
|---|---|
| `df.info()` | types de chaque colonne, nombre de valeurs non nulles, mémoire utilisée |
| `df.dtypes` | type de chaque colonne |
| `df.sample(5)` | 5 lignes tirées au hasard (plus représentatif que `head`) |
| `df.isnull().sum()` | nombre de valeurs manquantes par colonne |

Sur ce jeu, `df.info()` révélerait immédiatement que `price_paid` est du texte et que `tax`, `gender` et `country` ont des valeurs manquantes (346, 69 et 44).

---

## À retenir

- `head()`, `tail()`, `shape`, `columns`, `index` : la trousse d'inspection de base.
- Attribut (`shape`) ou méthode (`head()`) : attention aux parenthèses.
- La plupart des méthodes pandas renvoient une copie et ne modifient pas l'objet d'origine.

## Pour s'exercer

1. Afficher les 3 dernières lignes.
2. Vérifier que la colonne `email` ne contient pas de doublon : `df["email"].is_unique`.
3. Mettre `id` en index de façon permanente, puis afficher la ligne d'identifiant 42.
