# TP 07 : Analyser des données (statistiques et regroupements)

**Notebook source :** `07_analyser_des_donnees.ipynb`
**Jeu de données :** `data.csv` après nettoyage
**Objectif :** résumer les données avec des statistiques descriptives, compter les catégories et comparer des groupes avec `groupby`.

---

## Contexte

Une fois les données propres, on peut répondre à des questions : quel est le panier moyen ? Quel pays rapporte le plus ? Les femmes et les hommes dépensent-ils autant ? C'est l'**analyse descriptive**, première étape de tout projet de data science, avant la modélisation.

---

## Instruction par instruction

### 1. Préparation et nettoyage (repris des TP 05 et 06)

```python
import pandas as pd
df = pd.read_csv("data.csv")
df.dropna(subset=["tax"], inplace=True)
df.price_paid = df.price_paid.apply(lambda x: x.replace("$", ""))
df.price_paid = df.price_paid.astype(float)
df["price_total"] = df["price_paid"] * (1 - df["tax"] / 100)
```

- Suppression des lignes sans taxe (654 lignes restantes), conversion du prix, calcul de `price_total`. Voir TP 05 et TP 06 pour le détail.

```python
df.drop(["first_name", "last_name", "email", "ip_address", "id"], axis=1, inplace=True)
df
```

- On retire les données personnelles et l'identifiant (voir TP 04). Il reste `date`, `gender`, `country`, `price_paid`, `tax`, `price_total`.

### 2. Résumé statistique global

```python
df.describe()
```

- Calcule pour chaque colonne **numérique** : `count` (valeurs non nulles), `mean` (moyenne), `std` (écart-type), `min`, `25%` (premier quartile), `50%` (médiane), `75%` (troisième quartile), `max`.
- Pour `price_total` : moyenne 5,10, écart-type 1,64, minimum 2,40, médiane 4,97, maximum 8,00.
- La colonne `tax` n'a qu'une valeur (20) : son écart-type est nul, ce qui signale qu'elle n'apporte aucune information.
- Moyenne et médiane proches : la distribution est à peu près symétrique.
- `df.describe(include="all")` ajoute les colonnes de texte (nombre de valeurs distinctes, valeur la plus fréquente).

### 3. Statistiques sur une colonne

```python
df["price_total"].mean()
```

- Moyenne : environ **5,10**. Les `NaN` sont ignorés automatiquement.

```python
df["price_total"].sum()
```

- Somme : environ **3 333,72** (chiffre d'affaires total au sens de cette colonne).

```python
print(df["price_total"].min())
print(df["price_total"].max())
```

- Minimum (2,40) et maximum (8,00). Le `print` est nécessaire : dans une cellule Jupyter, seule la **dernière** expression s'affiche automatiquement.

### 4. Explorer une colonne catégorielle

```python
df["country"].unique().tolist()
```

- `unique()` renvoie les valeurs distinctes : `['United States', 'Morocco', 'France', 'Canada', nan]`. Le `nan` rappelle qu'il reste des pays manquants.

```python
df["country"].value_counts()
```

- Compte les occurrences de chaque valeur, triées de la plus fréquente à la moins fréquente : France 255, United States 226, Canada 108, Morocco 39.
- Les `NaN` sont exclus par défaut ; `value_counts(dropna=False)` les inclut (26).

```python
df["gender"].value_counts()
df["gender"].value_counts(normalize=True)
```

- Première ligne : effectifs.
- Deuxième ligne : `normalize=True` donne des **proportions** (fréquences relatives) : Female 52,8 %, Male 47,2 %, calculées sur les valeurs non manquantes.

### 5. Regrouper avec `groupby`

`groupby` applique la logique **diviser, appliquer, combiner** : on découpe le tableau en groupes selon une colonne, on calcule une statistique dans chaque groupe, et on rassemble les résultats.

```python
df.groupby("country").sum()
```

- Somme de chaque colonne, par pays.
- **Problème avec pandas récent :** la colonne `date` (texte) est aussi « sommée », ce qui revient à **concaténer** toutes les dates en une chaîne illisible. Il faut sélectionner les colonnes numériques :
  ```python
  df.groupby("country")[["price_paid", "price_total"]].sum()
  # ou
  df.groupby("country").sum(numeric_only=True)
  ```
- Résultat pour `price_total` : France 1 289,37, United States 1 178,88, Canada 536,76, Morocco 211,05.
- Les lignes sans pays sont exclues des groupes par défaut (`dropna=True`).

```python
df.groupby("gender")["price_total"].mean()
```

- Forme recommandée : on regroupe, on **choisit la colonne**, puis on calcule.
- Panier moyen : Female 5,12, Male 5,02. L'écart est très faible ; sans test statistique, on ne peut pas conclure à une vraie différence.

```python
df.groupby(["gender", "country"]).mean()
```

- Regroupement sur **deux colonnes** : un groupe par combinaison (Female/Canada, Female/France, ...). Le résultat a un **index à deux niveaux** (MultiIndex).
- **Échoue avec pandas 2 et 3** (`TypeError`) à cause de la colonne `date` en texte. Correction :
  ```python
  df.groupby(["gender", "country"])[["price_paid", "price_total"]].mean()
  ```
- `.unstack()` à la suite transforme le second niveau en colonnes, ce qui donne un tableau croisé plus lisible.

---

## Fonctions d'agrégation courantes

| Fonction | Résultat |
|---|---|
| `count()` | nombre de valeurs non nulles |
| `sum()`, `mean()`, `median()` | somme, moyenne, médiane |
| `min()`, `max()`, `std()` | extrêmes, écart-type |
| `nunique()` | nombre de valeurs distinctes |
| `agg(["mean", "sum", "count"])` | plusieurs statistiques à la fois |

## À retenir

- `describe()` donne un résumé en une ligne de code.
- `value_counts()` est l'outil des variables catégorielles ; `normalize=True` donne des proportions.
- `groupby(colonne)[colonne_cible].statistique()` est le schéma à retenir.
- Toujours sélectionner les colonnes numériques avant d'agréger.

## Pour s'exercer

1. Calculer le nombre d'achats et le panier moyen par pays en une seule instruction avec `agg`.
2. Trouver le pays au panier moyen le plus élevé (`idxmax()`).
3. Afficher le tableau croisé genre × pays des paniers moyens avec `unstack()`.
