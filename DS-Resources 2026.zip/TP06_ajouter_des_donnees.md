# TP 06 : Ajouter des données (colonnes calculées)

**Notebook source :** `06_ajouter_des_donnees.ipynb`
**Jeu de données :** `data.csv`
**Objectif :** nettoyer une colonne pour la rendre numérique, puis créer de nouvelles colonnes par calcul et par correspondance (dictionnaire).

---

## Contexte

Les colonnes d'origine ne suffisent pas toujours. On crée souvent des **variables dérivées** : un prix total, un code pays, une catégorie d'âge. En machine learning, cette étape porte un nom : le **feature engineering** (ingénierie des variables). Ce TP en montre les deux formes de base.

---

## Instruction par instruction

### 1. Préparation

```python
import pandas as pd
df = pd.read_csv("data.csv")
```

### 2. Retirer les lignes sans taxe

```python
df.dropna(subset=["tax"], inplace=True)
df
```

- Reprend la stratégie 3 du TP 05, cette fois de façon **définitive** (`inplace=True`) : `df` passe de 1 000 à 654 lignes.
- Nécessaire car le calcul du prix total utilise `tax` : avec un `NaN`, le résultat serait aussi `NaN`.
- L'index n'est pas renuméroté : il garde des « trous » (0, 2, 3, ...). Pour le renuméroter : `df.reset_index(drop=True)`.

### 3. Convertir le prix en nombre

```python
df.price_paid = df.price_paid.apply(lambda x: x.replace("$", ""))
df.price_paid = df.price_paid.astype(float)
df.dtypes
```

- Ligne 1 : retire le symbole `$` de chaque valeur (voir TP 03, partie F).
- Ligne 2 : convertit le texte en décimal.
- Ligne 3 : `df.dtypes` affiche le type de chaque colonne et confirme que `price_paid` est maintenant `float64`.

### 4. Créer une colonne par calcul

```python
df["price_total"] = df["price_paid"] * (1 - df["tax"] / 100)
df
```

- **Créer une colonne** : on affecte une valeur à un nom de colonne qui n'existe pas encore, avec les crochets. (La notation pointée `df.price_total = ...` ne fonctionnerait pas pour une nouvelle colonne.)
- Le calcul est **vectorisé** : pandas l'applique à toutes les lignes en une seule opération, sans boucle `for`. C'est beaucoup plus rapide et plus lisible.
- Pour une ligne avec `price_paid = 3.73` et `tax = 20` : `3.73 × (1 − 0.20) = 2.984`.
- **Attention au sens du calcul.** La formule retire 20 % du prix. Le nom `price_total` suggère un prix « toutes taxes comprises », qui s'obtiendrait plutôt avec `price_paid × 1.2`. Et si `price_paid` est déjà TTC, le prix hors taxe vaut `price_paid / 1.2` (et non `× 0.8`). Le notebook ne précise pas l'interprétation : il faut la fixer avant d'utiliser cette colonne.

### 5. Créer une colonne par correspondance

```python
countries = {"United States": "UN", "France": "FR", "Canada": "CA", "Morocco": "MA"}
df["country_code"] = df["country"].map(countries)
df
```

- `countries` est un **dictionnaire** Python : à chaque nom de pays (la clé) correspond un code (la valeur).
- `map(countries)` remplace chaque valeur de `country` par la valeur associée dans le dictionnaire.
- Les pays absents du dictionnaire, ainsi que les `NaN` (26 lignes restantes), donnent `NaN` dans `country_code`.
- **Erreur dans le notebook :** le code ISO des États-Unis est `"US"`, pas `"UN"` (qui évoque plutôt les Nations unies). À corriger.

---

## Autres façons de créer des colonnes

| Méthode | Exemple |
|---|---|
| Valeur constante | `df["devise"] = "USD"` |
| Calcul entre colonnes | `df["taxe_montant"] = df["price_paid"] * df["tax"] / 100` |
| Condition | `df["gros_achat"] = df["price_paid"] > 8` |
| Fonction sur chaque valeur | `df["initiale"] = df["first_name"].apply(lambda x: x[0])` |
| Correspondance | `df["code"] = df["country"].map(dictionnaire)` |
| Plusieurs colonnes à la fois | `df.assign(a=..., b=...)` |

## À retenir

- `df["nouvelle"] = ...` crée une colonne. Il faut utiliser les crochets.
- Les opérations sur les colonnes sont vectorisées : pas de boucle.
- `map` avec un dictionnaire traduit des valeurs ; ce qui n'est pas prévu devient `NaN`.
- Une colonne calculée doit avoir une définition claire.

## Pour s'exercer

1. Corriger le code pays des États-Unis et vérifier avec `value_counts()`.
2. Créer `prix_ht = price_paid / 1.2` et le comparer à `price_total`.
3. Créer une colonne `categorie` qui vaut `"élevé"` si le prix dépasse 7 $ et `"standard"` sinon (indice : `numpy.where`).
