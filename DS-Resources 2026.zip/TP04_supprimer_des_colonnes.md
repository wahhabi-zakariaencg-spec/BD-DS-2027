# TP 04 : Supprimer des colonnes (et des lignes)

**Notebook source :** `04_supprimer_des_colonnes.ipynb`
**Jeu de données :** `data.csv`
**Objectif :** retirer d'un DataFrame les colonnes inutiles ou les lignes indésirables, en comprenant la notion d'axe et le paramètre `inplace`.

---

## Contexte

Un jeu de données contient souvent des informations sans intérêt pour l'analyse, ou sensibles. Ici, `first_name`, `last_name`, `email` et `ip_address` sont des **données personnelles** qui n'apportent rien à une analyse des ventes. Les supprimer allège le tableau, accélère les calculs et protège la vie privée des clients.

---

## Instruction par instruction

### 1. Préparation

```python
import pandas as pd
df = pd.read_csv("data.csv")
```

### 2. Supprimer une colonne

```python
df.drop("ip_address", axis=1)
```

- `drop` supprime des éléments désignés par leur **étiquette**.
- `"ip_address"` est l'étiquette à supprimer.
- `axis=1` indique qu'il s'agit d'une **colonne**.
- Comme la plupart des méthodes pandas, `drop` renvoie une **copie** sans la colonne : `df` lui-même est inchangé. Le résultat est seulement affiché.
- Écriture équivalente et plus explicite : `df.drop(columns="ip_address")`.

### 3. La notion d'axe

Un DataFrame a deux axes :

| Axe | Valeur | Désigne | Étiquettes |
|---|---|---|---|
| Lignes | `axis=0` | les rangées | l'index |
| Colonnes | `axis=1` | les colonnes | les noms de colonnes |

Avec `axis=0` (valeur par défaut), `drop` cherche l'étiquette **dans l'index**. Avec `axis=1`, il la cherche **dans les noms de colonnes**.

### 4. Supprimer des lignes grâce à l'index

```python
df_gender = df.copy()
```

- Copie de travail pour ne pas abîmer `df`.

```python
df_gender.set_index("gender", inplace=True)
```

- La colonne `gender` devient l'index. Plusieurs lignes partagent alors la même étiquette (`"Male"`, `"Female"` ou `NaN`) : un index n'est pas obligatoirement unique.
- `inplace=True` applique la modification **directement** à `df_gender`, sans renvoyer de copie (la méthode renvoie `None`).

```python
df_gender.drop("Male", axis=0, inplace=True)
df_gender
```

- `axis=0` : on cherche `"Male"` dans l'index, donc on supprime **toutes les lignes** étiquetées `"Male"` (438 lignes).
- Il reste 562 lignes : 493 femmes et 69 lignes au genre inconnu.
- La deuxième ligne affiche le résultat.
- En pratique, on obtient le même effet plus simplement avec un filtre : `df[df["gender"] != "Male"]`. L'intérêt de l'exemple est de montrer que `axis=0` agit sur l'index.

### 5. Supprimer avec `del`

```python
del df_gender["id"]
df_gender
```

- `del` est un mot-clé Python (pas une méthode pandas) qui supprime la colonne `id` **directement** dans l'objet.
- Il ne supprime qu'une colonne à la fois et ne s'applique pas aux lignes.

### 6. Supprimer plusieurs colonnes d'un coup

```python
df
```

- Réaffiche `df` pour constater qu'il possède toujours ses 10 colonnes : les opérations précédentes ne l'ont pas modifié.

```python
df.drop(['first_name', 'last_name', 'email', 'ip_address'], axis=1, inplace=True)
df.head()
```

- On passe une **liste** de colonnes à `drop`.
- `inplace=True` modifie `df` définitivement : il ne reste que `id`, `date`, `gender`, `country`, `price_paid` et `tax`.
- `df.head()` confirme le résultat.

---

## `inplace=True` ou réaffectation ?

Deux styles produisent le même résultat :

```python
df.drop(columns=["email"], inplace=True)   # style 1
df = df.drop(columns=["email"])            # style 2
```

La documentation de pandas et la plupart des praticiens recommandent aujourd'hui le **style 2** : il est plus lisible, permet d'enchaîner les méthodes, et `inplace` n'apporte en général aucun gain de performance. Il faut toutefois savoir lire les deux.

Attention : exécuter deux fois une cellule avec `inplace=True` provoque une `KeyError`, car la colonne a déjà disparu. Dans Jupyter, l'ordre d'exécution des cellules compte.

---

## À retenir

- `drop(étiquette, axis=1)` supprime des colonnes, `axis=0` des lignes.
- Sans `inplace=True` ni réaffectation, rien n'est modifié.
- Supprimer les données personnelles inutiles est une bonne pratique (minimisation des données).

## Pour s'exercer

1. Supprimer la colonne `tax` avec `drop(columns=...)` en réaffectant le résultat dans une nouvelle variable.
2. Supprimer les lignes 0 à 9 (`df.drop(range(10))`) et vérifier avec `shape`.
3. Mettre `country` en index et supprimer toutes les lignes `"France"`.
