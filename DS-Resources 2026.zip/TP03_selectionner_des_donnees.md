# TP 03 : Sélectionner des données

**Notebook source :** `03_selectionner_des_donnees.ipynb`
**Jeu de données :** `data.csv`
**Objectif :** extraire des colonnes, des lignes et des sous-ensembles qui respectent une condition (filtres).

---

## Contexte

Analyser des données, c'est presque toujours poser une question sur un **sous-ensemble** : les clients d'un pays, les achats au-dessus d'un montant, etc. Ce TP présente les trois outils de sélection de pandas : par nom de colonne, par position ou étiquette de ligne, et par condition logique.

---

## Instruction par instruction

### 1. Préparation

```python
import pandas as pd
df = pd.read_csv("data.csv")
```

### Partie A : sélectionner une colonne

```python
df["email"].head()
```

- `df["email"]` extrait la colonne `email`. La notation entre crochets avec le nom en texte est la **forme standard**.
- `.head()` limite l'affichage aux 5 premières valeurs.

```python
df.email.head()
```

- Même résultat avec la **notation pointée** (la colonne est accessible comme un attribut).
- Plus rapide à écrire, mais elle ne fonctionne pas si le nom contient un espace (`df.prix payé`), commence par un chiffre ou porte le nom d'une méthode existante (une colonne `count` ou `shape`). Elle ne permet pas non plus de **créer** une colonne. La notation `df["..."]` est donc la plus sûre.

### Partie B : DataFrame ou Series ?

```python
type(df)
type(df["email"])
```

- `type(df)` donne `pandas.core.frame.DataFrame` : un tableau à deux dimensions.
- `type(df["email"])` donne `pandas.core.series.Series` : une **seule colonne**, c'est-à-dire un vecteur à une dimension avec un index.
- Cette distinction compte, car certaines méthodes n'existent que sur l'un des deux (par exemple `value_counts()` est une méthode de Series).
- Astuce : `df[["email"]]` (doubles crochets, donc une liste de colonnes) renvoie un DataFrame d'une seule colonne.

### Partie C : sélectionner des lignes

```python
df[10:20]
```

- Découpage **par position**, comme une liste Python : lignes 10 à 19. La borne de fin est **exclue**.

```python
df[10:13]
```

- Lignes 10, 11 et 12 (3 lignes).

```python
df.loc[10:13]
```

- `loc` sélectionne **par étiquette d'index**, et la borne de fin est **incluse** : lignes 10, 11, 12 et 13 (4 lignes).
- Ici les étiquettes et les positions coïncident (index 0 à 999), d'où la ressemblance. La différence entre `[10:13]` (3 lignes) et `loc[10:13]` (4 lignes) est l'un des points clés du TP.
- Pour sélectionner **par position** de façon explicite, pandas propose `iloc` : `df.iloc[10:13]` (borne exclue).

```python
df_email = df.set_index("email")
df_email.loc['hharridge1@gnu.org'].values
```

- On crée un nouveau DataFrame indexé par courriel (voir TP 02) et on le **conserve** dans `df_email`.
- `df_email.loc['hharridge1@gnu.org']` retourne la ligne de ce client sous forme de Series.
- `.values` convertit le résultat en tableau NumPy, c'est-à-dire les valeurs brutes sans étiquettes.

```python
df_email.loc[['hharridge1@gnu.org', 'derrigorn@elpais.com']]
```

- En passant une **liste** d'étiquettes, on obtient plusieurs lignes, sous forme de DataFrame.

### Partie D : les filtres (indexation booléenne)

```python
df["gender"] == "Male"
```

- Compare chaque valeur de la colonne à `"Male"` et renvoie une **Series de booléens** (`True` / `False`) de 1 000 éléments. C'est un **masque**.
- Les valeurs manquantes donnent `False`.

```python
df[df["gender"] == "Male"]
```

- En passant ce masque entre crochets, pandas ne garde que les lignes où il vaut `True` : 438 clients masculins.

```python
male_filter = df["gender"] == "Male"
df[male_filter]
```

- Même résultat, mais le masque est stocké dans une variable. Le code est plus lisible et le filtre réutilisable.
- On peut combiner des masques avec `&` (et), `|` (ou), `~` (non), en mettant chaque condition entre parenthèses :
  `df[(df["gender"] == "Male") & (df["country"] == "France")]`.

```python
df[df["country"].isin(("France", "Canada"))]
```

- `isin` teste l'appartenance à un ensemble de valeurs : on garde les clients français **ou** canadiens (569 lignes). C'est plus court qu'enchaîner des `|`.

### Partie E : une erreur volontaire

```python
df[df["price_paid"] > 5]  # TypeError
```

- Cette ligne échoue avec une `TypeError`, et c'est voulu.
- `price_paid` contient du **texte** (`"$5.36"`) : on ne peut pas comparer une chaîne de caractères à un nombre.
- Leçon : **le type d'une colonne conditionne les opérations possibles**. Il faut d'abord nettoyer.

### Partie F : la correction

```python
df_test = df.copy()
```

- Crée une **copie indépendante** de `df`. Les modifications qui suivent ne toucheront pas les données d'origine. Sans `.copy()`, `df_test = df` créerait seulement un second nom pour le même objet.

```python
df_test.price_paid = df_test.price_paid.apply(lambda x: x.replace("$", ""))
```

- `apply` exécute une fonction sur **chaque valeur** de la colonne.
- `lambda x: x.replace("$", "")` est une fonction anonyme : elle reçoit une valeur `x` (ex. `"$5.36"`) et renvoie la même chaîne sans le `$` (`"5.36"`).
- Le résultat est réaffecté à la colonne. Il s'agit toujours de texte.
- Version plus directe et plus rapide : `df_test["price_paid"].str.replace("$", "", regex=False)`.

```python
df_test.price_paid = df_test.price_paid.astype(float)
```

- `astype(float)` convertit le texte `"5.36"` en nombre décimal `5.36`. Les comparaisons et calculs deviennent possibles.

```python
df_test[df_test["price_paid"] >= 5.0]
```

- Le filtre fonctionne désormais : 696 achats d'au moins 5 $ (les prix vont de 3 $ à 10 $).

---

## Tableau récapitulatif

| Besoin | Syntaxe | Remarque |
|---|---|---|
| Une colonne | `df["col"]` | renvoie une Series |
| Plusieurs colonnes | `df[["a", "b"]]` | renvoie un DataFrame |
| Lignes par position | `df[10:13]` ou `df.iloc[10:13]` | fin exclue |
| Lignes par étiquette | `df.loc[10:13]` | fin incluse |
| Lignes et colonnes | `df.loc[10:13, ["email", "country"]]` | |
| Filtre | `df[df["col"] == valeur]` | masque booléen |
| Plusieurs valeurs | `df[df["col"].isin([...])]` | |

## À retenir

- Series (une colonne) et DataFrame (un tableau) sont deux objets différents.
- `loc` inclut la borne de fin, le découpage simple et `iloc` l'excluent.
- Un filtre est un masque de booléens.
- Avant de comparer ou calculer, vérifier le type de la colonne.

## Pour s'exercer

1. Afficher les clientes marocaines.
2. Afficher les achats de plus de 8 $ effectués au Canada.
3. Afficher uniquement les colonnes `email` et `country` des lignes 100 à 105 avec `loc`.
