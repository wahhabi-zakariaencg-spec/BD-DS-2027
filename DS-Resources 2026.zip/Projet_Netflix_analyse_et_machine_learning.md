# Projet Netflix : analyse exploratoire et modèle de prédiction

**Notebook source :** `analyse_netflix.ipynb`
**Jeu de données :** `netflix_titles.csv`
**Script complémentaire :** `netflix_ml.py` (partie machine learning)
**Notions mobilisées :** TP 01 à 07, plus le traitement de chaînes de caractères et la régression linéaire.

---

## Note importante sur le périmètre

Le notebook d'origine `analyse_netflix.ipynb` est une **analyse exploratoire** : il répond à quatre questions descriptives avec pandas et **ne contient aucun modèle de machine learning**. La partie 3 de ce document est donc un **prolongement** construit sur les mêmes données : un modèle de régression linéaire qui prédit la durée d'un film. Il a été réellement entraîné et évalué, et tous les chiffres cités proviennent de son exécution (`python netflix_ml.py`). Ce prolongement part volontairement de la première question du notebook (la durée moyenne des films), car cette moyenne est précisément le prédicteur le plus simple possible, que le modèle doit battre.

---

## 1. Les données

`netflix_titles.csv` décrit le catalogue Netflix : **7 787 titres** et **12 colonnes**.

| Colonne | Contenu | Particularité |
|---|---|---|
| `show_id` | identifiant (`s1`, `s2`, ...) | unique |
| `type` | `Movie` (5 377) ou `TV Show` (2 410) | |
| `title` | titre | |
| `director` | réalisateur(s) | 2 389 manquants |
| `cast` | acteurs, séparés par des virgules | 718 manquants, multivaluée |
| `country` | pays de production, séparés par des virgules | 507 manquants, multivaluée |
| `date_added` | date d'ajout au catalogue, ex. `August 14, 2020` | texte |
| `release_year` | année de sortie (1925 à 2021) | entier |
| `rating` | classification d'âge (`TV-MA`, `PG-13`, ...) | 7 manquants |
| `duration` | `93 min` pour un film, `4 Seasons` pour une série | **deux unités mélangées** |
| `listed_in` | genres, séparés par des virgules | multivaluée |
| `description` | résumé | texte libre |

Ce jeu est plus réaliste que `data.csv` : valeurs manquantes nombreuses, colonnes contenant plusieurs valeurs dans une même cellule, et une colonne (`duration`) dont le sens dépend d'une autre (`type`).

---

## 2. L'analyse exploratoire du notebook

### 2.1 Chargement

```python
import pandas as pd
df = pd.read_csv("netflix_titles.csv")
```

Import de pandas et lecture du fichier (voir TP 01).

### 2.2 Question 1 : durée moyenne des films

```python
df_duration = df[df["duration"].str.contains("min")]["duration"]
df_duration.str.replace("min", "").map(int).mean()
```

- `df["duration"].str.contains("min")` : l'accesseur `.str` donne accès aux méthodes de texte sur chaque valeur. On obtient un masque : `True` si la durée contient `"min"`, donc si c'est un film.
- `df[masque]["duration"]` : on filtre les lignes (TP 03), puis on garde la colonne `duration`.
- `.str.replace("min", "")` : retire l'unité. `"93 min"` devient `"93 "`.
- `.map(int)` : applique la fonction `int` à chaque valeur, ce qui convertit le texte en entier (`int` tolère l'espace final).
- `.mean()` : moyenne.

**Résultat : 99,3 minutes.** La médiane est de 98 minutes, l'écart-type de 28,5 minutes, avec des extrêmes à 3 et 312 minutes (courts métrages et films très longs).

**Remarque :** filtrer avec `df["type"] == "Movie"` serait plus robuste que chercher la chaîne `"min"`. Les deux donnent ici les mêmes 5 377 films.

### 2.3 Question 2 : pays les plus représentés

```python
df["country"].value_counts()[:3].to_dict()
```

- `value_counts()` compte les titres par valeur de `country` (TP 07).
- `[:3]` garde les trois premiers, `.to_dict()` convertit en dictionnaire.
- **Résultat :** `{'United States': 2555, 'India': 923, 'United Kingdom': 397}`.

**Limite importante :** une coproduction comme `"United States, India"` est comptée comme une valeur à part entière, distincte de `"United States"`. Les pays très coproducteurs sont donc sous-estimés. Version corrigée :

```python
df["country"].str.split(", ").explode().value_counts()[:3]
```

- `str.split(", ")` transforme chaque cellule en liste de pays.
- `explode()` crée une ligne par élément de liste.
- **Résultat corrigé :** United States 3 296, India 990, United Kingdom 722. Le Royaume-Uni passe de 397 à 722 titres.

### 2.4 Question 3 : titres par année de sortie

```python
df["release_year"].value_counts().sort_index(ascending=False)[:10]
```

- `value_counts()` compte les titres par année.
- `sort_index(ascending=False)` trie par année décroissante (l'année est dans l'index), au lieu du tri par fréquence.
- `[:10]` garde les dix années les plus récentes.
- **Résultat :** pic en 2018 (1 121 titres), puis 2019 (996), 2020 (868) et seulement 31 titres pour 2021, car le jeu a été extrait début 2021.

**Limite :** la section s'intitule « Nombre de films par année », mais le calcul compte **films et séries**. Pour les films seuls, il faut filtrer : `df[df["type"] == "Movie"]["release_year"].value_counts()`. En 2020, on passe de 868 titres à 411 films.

### 2.5 Question 4 : liste des réalisateurs

```python
df.director.dropna().unique().tolist()[:10]
```

- `df.director` : la colonne en notation pointée (TP 03).
- `.dropna()` : retire les 2 389 valeurs manquantes (TP 05).
- `.unique()` : réalisateurs distincts.
- `.tolist()[:10]` : conversion en liste et affichage des dix premiers.

**Limite :** comme pour les pays, une cellule peut contenir plusieurs réalisateurs (`"Réalisateur A, Réalisateur B"`). La même correction avec `str.split(", ").explode()` s'applique.

### 2.6 Bilan de l'analyse exploratoire

| Question | Résultat du notebook | Après correction |
|---|---|---|
| Durée moyenne d'un film | 99,3 min | inchangé (médiane 98 min) |
| Pays n° 1, 2, 3 | US 2 555, Inde 923, R.-U. 397 | US 3 296, Inde 990, R.-U. 722 |
| Année la plus fournie | 2018 | inchangé, mais films et séries mélangés |
| Réalisateurs | liste brute | à éclater pour les coréalisations |

---

## 3. Prolongement : le machine learning adopté

### 3.1 Le problème posé

**Question :** à partir des caractéristiques d'un film (genres, pays, année), peut-on **prédire sa durée** ?

En vocabulaire de machine learning :

| Terme | Ici |
|---|---|
| Type d'apprentissage | **supervisé** : on apprend à partir d'exemples dont on connaît la réponse |
| Type de tâche | **régression** : la réponse est un nombre (des minutes) et non une catégorie |
| Variable cible `y` | `duree` (durée du film en minutes) |
| Variables explicatives `X` | année de sortie, 10 indicateurs de genre, 2 indicateurs de pays |
| Observations | les 5 377 films du catalogue |

### 3.2 Pourquoi la régression linéaire ?

D'autres modèles (forêts aléatoires, gradient boosting) seraient probablement un peu plus précis. La régression linéaire a été choisie pour trois raisons pédagogiques :

1. **Elle produit une fonction de prédiction explicite**, une simple formule qu'on peut écrire, lire et calculer à la main.
2. **Chaque coefficient s'interprète** directement en minutes.
3. C'est le modèle de référence de la statistique : il fait le lien entre l'analyse descriptive des TP et le machine learning.

### 3.3 Préparation des données

```python
films = df[df["type"] == "Movie"].copy()
films["duree"] = films["duration"].str.replace(" min", "", regex=False).astype(int)
```

- On ne garde que les films, car la durée d'une série est en saisons (unité incompatible).
- On convertit la durée en entier, comme dans la question 1.

**Construction des variables explicatives (feature engineering)**

Un modèle mathématique ne comprend que des nombres. Il faut donc traduire le texte en variables numériques.

```python
X = pd.DataFrame(index=films.index)
X["annee_depuis_2000"] = films["release_year"] - 2000
```

- L'année est recentrée sur 2000 : un film de 2019 vaut 19, un film de 1995 vaut -5. Cela ne change pas les prédictions, mais rend la constante du modèle interprétable (un film de l'an 2000).

```python
X["drame"] = films["listed_in"].str.contains("Dramas", regex=False).astype(int)
# ... même principe pour les 9 autres genres
```

- Pour chaque genre retenu, on crée une **variable indicatrice** (ou variable binaire) qui vaut 1 si le film appartient au genre, 0 sinon. C'est le principe de l'encodage « one-hot ». Comme un film peut avoir plusieurs genres, plusieurs indicatrices peuvent valoir 1 en même temps.
- Les 10 genres retenus sont parmi les plus fréquents : drame, comédie, documentaire, action, jeunesse et famille, romance, stand-up, horreur, comédie musicale, international.

```python
pays = films["country"].fillna("")
X["inde"] = pays.str.contains("India").astype(int)
X["etats_unis"] = pays.str.contains("United States").astype(int)
```

- Indicatrices de pays pour les deux principaux producteurs. Les pays manquants sont remplacés par une chaîne vide (TP 05), ce qui donne 0 aux deux indicatrices.

### 3.4 Séparation entraînement / test

```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

- 80 % des films (4 301) servent à **entraîner** le modèle, 20 % (1 076) sont mis de côté pour le **tester**.
- Pourquoi : un modèle évalué sur les données qui ont servi à l'entraîner paraît toujours meilleur qu'il ne l'est. Le jeu de test simule des films « jamais vus ».
- `random_state=42` fixe le tirage aléatoire pour que les résultats soient reproductibles.

### 3.5 Le modèle de référence (baseline)

Avant tout modèle, on se demande : que vaut une prédiction naïve ? La plus simple consiste à prédire **toujours la durée moyenne**, soit 99,1 minutes sur le jeu d'entraînement. C'est exactement le résultat de la question 1 du notebook. Un modèle n'a d'intérêt que s'il fait mieux que cette référence.

### 3.6 L'entraînement

```python
modele = LinearRegression().fit(X_train, y_train)
```

La régression linéaire suppose que la durée s'écrit comme une **somme pondérée** des variables :

$$\hat{y} = b_0 + b_1 x_1 + b_2 x_2 + \dots + b_{13} x_{13}$$

- $\hat{y}$ est la durée prédite, $x_1, \dots, x_{13}$ les variables explicatives, $b_0$ la constante, $b_1, \dots, b_{13}$ les coefficients.
- **Entraîner** le modèle, c'est trouver les coefficients qui minimisent la **somme des carrés des erreurs** sur les films d'entraînement :

$$\min_{b_0, \dots, b_{13}} \sum_{i=1}^{n} \left(y_i - \hat{y}_i\right)^2$$

- C'est la méthode des **moindres carrés ordinaires**. Elle a une solution exacte, calculée par algèbre linéaire, sans itérations : $b = (X^\top X)^{-1} X^\top y$ (en ajoutant une colonne de 1 à $X$ pour la constante).

### 3.7 L'évaluation

```python
pred = modele.predict(X_test)
```

Trois mesures, calculées sur les 1 076 films de test :

| Mesure | Définition | Référence (moyenne) | Régression linéaire |
|---|---|---|---|
| **MAE** (erreur absolue moyenne) | écart moyen entre prédiction et réalité, en minutes | 19,75 min | **15,55 min** |
| **RMSE** (racine de l'erreur quadratique moyenne) | comme la MAE, mais pénalise davantage les grosses erreurs | 27,94 min | **21,60 min** |
| **R²** (coefficient de détermination) | part de la variabilité des durées expliquée par le modèle (0 = rien, 1 = tout) | 0,00 | **0,40** |

**Validation croisée.** Pour vérifier que ce résultat ne dépend pas d'un découpage chanceux, on répète l'entraînement sur 5 découpages différents (`cross_val_score`, 5 plis). Le R² moyen vaut **0,42** avec un écart-type de 0,07 : le résultat est stable.

**Interprétation :** le modèle réduit l'erreur moyenne d'environ 4 minutes (de 19,8 à 15,6) par rapport à la prédiction naïve, et explique **environ 40 %** de la variabilité des durées. Les 60 % restants dépendent de facteurs absents des données (choix du réalisateur, budget, scénario, etc.).

### 3.8 Le modèle obtenu : les coefficients

| Variable | Coefficient (min) | Interprétation, toutes choses égales par ailleurs |
|---|---|---|
| Constante $b_0$ | **86,80** | durée prédite d'un film de 2000, sans aucun des genres ni pays retenus |
| `inde` | **+19,70** | un film produit en Inde dure environ 20 min de plus |
| `standup` | **-18,11** | un spectacle de stand-up dure environ 18 min de moins |
| `drame` | **+13,99** | |
| `musical` | **+13,48** | |
| `action` | **+13,43** | |
| `jeunesse_famille` | **-12,69** | les films pour enfants sont plus courts |
| `documentaire` | **-10,47** | |
| `international` | **+9,56** | |
| `romance` | **+7,03** | |
| `etats_unis` | **+5,70** | |
| `horreur` | **+5,21** | |
| `comedie` | **+4,82** | |
| `annee_depuis_2000` | **-0,35** | chaque année plus récente retire environ 0,35 min |

Lecture : le facteur le plus fort est l'origine indienne, cohérent avec la tradition de longs films de Bollywood. Le stand-up, la jeunesse et le documentaire tirent la durée vers le bas. L'effet de l'année est faible : environ 3,5 minutes de moins sur dix ans.

**Précaution :** ce sont des **associations**, pas des causes. Le coefficient `inde` ne signifie pas que produire un film en Inde « le rallonge » : il signifie que, dans ce catalogue, les films indiens sont en moyenne plus longs, à genres et année égaux.

---

## 4. La fonction de prédiction déduite

### 4.1 Forme mathématique

En remplaçant les coefficients par leurs valeurs (arrondies au centième) :

$$
\begin{aligned}
\widehat{\text{durée}} = \; & 86{,}80 \; - \; 0{,}35 \times (\text{année} - 2000) \\
& + 13{,}99 \cdot \text{drame} + 4{,}82 \cdot \text{comédie} - 10{,}47 \cdot \text{documentaire} \\
& + 13{,}43 \cdot \text{action} - 12{,}69 \cdot \text{jeunesse} + 7{,}03 \cdot \text{romance} \\
& - 18{,}11 \cdot \text{standup} + 5{,}21 \cdot \text{horreur} + 13{,}48 \cdot \text{musical} \\
& + 9{,}56 \cdot \text{international} + 19{,}70 \cdot \text{Inde} + 5{,}70 \cdot \text{États-Unis}
\end{aligned}
$$

où chaque variable de genre ou de pays vaut 1 si elle s'applique au film, et 0 sinon.

### 4.2 Version Python autonome

Cette fonction n'a plus besoin de scikit-learn ni des données : elle encode le modèle entraîné.

```python
COEFFICIENTS = {
    "drame": 13.99, "comedie": 4.82, "documentaire": -10.47, "action": 13.43,
    "jeunesse_famille": -12.69, "romance": 7.03, "standup": -18.11,
    "horreur": 5.21, "musical": 13.48, "international": 9.56,
    "inde": 19.70, "etats_unis": 5.70,
}
CONSTANTE = 86.80
COEF_ANNEE = -0.35

def predire_duree(annee, genres=(), pays=()):
    """Prédit la durée d'un film (en minutes).

    annee  : année de sortie, ex. 2019
    genres : noms parmi drame, comedie, documentaire, action, jeunesse_famille,
             romance, standup, horreur, musical, international
    pays   : noms parmi inde, etats_unis
    """
    duree = CONSTANTE + COEF_ANNEE * (annee - 2000)
    for nom in list(genres) + list(pays):
        duree += COEFFICIENTS[nom]
    return round(duree, 1)
```

### 4.3 Exemples de calcul

**Exemple 1 : un drame international indien de 2019**

| Terme | Valeur |
|---|---|
| Constante | 86,80 |
| Année : -0,35 × 19 | -6,65 |
| Drame | +13,99 |
| International | +9,56 |
| Inde | +19,70 |
| **Durée prédite** | **≈ 123,4 min** |

```python
predire_duree(2019, genres=["drame", "international"], pays=["inde"])  # 123.4
```

**Autres exemples :**

| Film | Calcul | Prédiction |
|---|---|---|
| Documentaire américain, 2020 | 86,80 - 7,00 - 10,47 + 5,70 | ≈ 75,0 min |
| Spectacle de stand-up américain, 2018 | 86,80 - 6,30 - 18,11 + 5,70 | ≈ 68,1 min |
| Film d'action américain, 2010 | 86,80 - 3,50 + 13,43 + 5,70 | ≈ 102,4 min |

(Le modèle scikit-learn, qui utilise les coefficients non arrondis, donne 123,5 ; 75,1 ; 68,2 et 102,5 minutes.)

---

## 5. Limites du modèle

- **Précision modeste.** Une erreur moyenne de 15,6 minutes et un R² de 0,40 conviennent pour dégager des tendances, pas pour une prédiction fine d'un film particulier.
- **Hypothèse d'additivité.** Le modèle additionne les effets : un drame indien gagne +14 et +20 minutes, sans interaction possible. En réalité, l'effet d'un genre peut dépendre du pays.
- **Hypothèse de linéarité.** L'effet de l'année est supposé constant sur toute la période 1942 à 2021.
- **Valeurs extrêmes.** Les courts métrages (146 films de moins de 40 minutes) et les très longs films (38 films de plus de 3 heures) pèsent lourd dans les moindres carrés.
- **Variables limitées.** Seuls 10 genres et 2 pays sont retenus ; un film d'un autre pays ou genre reçoit seulement la constante et l'effet de l'année.
- **Association et non causalité** (voir 3.8).
- **Domaine de validité.** Le modèle décrit le catalogue Netflix de début 2021 ; il ne s'applique pas tel quel à d'autres catalogues.

## 6. Pistes d'amélioration

1. Ajouter des variables : tous les genres, plus de pays, la classification d'âge (`rating`), le nombre d'acteurs.
2. Ajouter des interactions (genre × pays) ou passer à un modèle non linéaire (arbre de décision, forêt aléatoire, gradient boosting), au prix d'une interprétation moins directe.
3. Exploiter le texte de `description` (TF-IDF) pour capter le contenu du film.
4. Utiliser une perte moins sensible aux extrêmes (régression de Huber) ou prédire le logarithme de la durée.
5. Changer de question : classer un titre en film ou série, ou prédire sa classification d'âge (tâches de **classification**).

---

## 7. Lien avec les TP

| Étape du projet | Notion | TP |
|---|---|---|
| `read_csv` | lecture | 01 |
| Inspection des colonnes | structure | 02 |
| Masques `str.contains`, `type == "Movie"` | filtres | 03 |
| `dropna`, `fillna("")` | valeurs manquantes | 05 |
| Variables indicatrices, `annee_depuis_2000` | colonnes calculées | 06 |
| `value_counts`, `mean`, `unique` | analyse descriptive | 07 |
| Régression linéaire, évaluation | **nouveau** : machine learning | Projet |

## 8. Reproduire les résultats

```bash
pip install pandas scikit-learn
python netflix_ml.py
```

Le script doit se trouver dans le même dossier que `netflix_titles.csv`. Résultats obtenus avec pandas 3.0 et scikit-learn 1.8.
